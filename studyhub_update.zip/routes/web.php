<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;

Route::get('/', function () {
    return Inertia::render('Welcome', [
        'canLogin' => Route::has('login'),
        'canRegister' => Route::has('register'),
        'laravelVersion' => Application::VERSION,
        'phpVersion' => PHP_VERSION,
    ]);
});


Route::get('/privacy', fn () => Inertia::render('Privacy'))->name('privacy');

Route::middleware('auth')->group(function () {
    Route::get('/profile/export', [ProfileController::class, 'export'])->name('profile.export');
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
    Route::get('/avatars/{user}', [ProfileController::class, 'avatar'])->name('profile.avatar');
});

require __DIR__.'/auth.php';
require __DIR__.'/studyhub-live.php';   // must be before studyhub.php
require __DIR__.'/studyhub-chat.php';
require __DIR__.'/studyhub.php';