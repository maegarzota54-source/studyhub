<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use HasFactory, Notifiable;
    protected $guarded = ['id', 'role', 'is_suspended'];
    protected $hidden = ['password', 'remember_token'];
    protected $appends = ['avatar_url'];

    protected function casts(): array {
        return ['email_verified_at' => 'datetime', 'password' => 'hashed',
                'study_preferences' => 'array', 'subjects' => 'array', 'availability' => 'array', 'privacy_consent_at' => 'datetime', 'last_seen_at' => 'datetime', 'is_suspended' => 'boolean'];
    }
    public function isAdmin(): bool { return $this->role === 'admin'; }
    public function groups() { return $this->belongsToMany(StudyGroup::class, 'group_members')->withPivot('role')->withTimestamps(); }
    /** Students who share at least one circle with this user. */
    public function circleMates() {
        $groupIds = $this->groups()->pluck('study_groups.id');
        return static::whereIn('id', \Illuminate\Support\Facades\DB::table('group_members')->whereIn('study_group_id', $groupIds)->pluck('user_id'))
            ->where('id', '!=', $this->id)->orderBy('name')->get(['id', 'name', 'avatar']);
    }
    public function studySessions() { return $this->hasMany(StudySession::class); }
    /**
     * Phase 1: avatars are served by the app itself (route profile.avatar), so nobody has to run
     * `php artisan storage:link`. The ?v= part changes whenever a new photo is uploaded, which busts the browser cache.
     */
    public function getAvatarUrlAttribute(): string {
        if ($this->avatar && $this->id) {
            return route('profile.avatar', $this->id, false).'?v='.substr(md5($this->avatar), 0, 8);
        }
        return 'https://ui-avatars.com/api/?background=355E3B&color=fff&name='.urlencode($this->name ?? 'User');
    }
}
